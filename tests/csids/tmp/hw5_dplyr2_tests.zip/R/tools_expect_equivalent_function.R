#' @importFrom purrr imap_chr
input_txt_one <- function(input, name,
                          islist = FALSE,
                          listname = NULL,
                          postfix = NULL) {
  if (!islist) {
    if (is.null(input)) {
      l <- 0
    } else {
      l <- max(sapply(input, function(x) ifelse(is.function(x), 0, length(x))))
    }
    input <- input[[1]]
  } else {
    l <- length(input)
  }
  type <- "input"
  if (!is.null(postfix)) {
    type <- paste0(type, "_", postfix)
  }
  if (is_atomic(input)) {
    if (islist) {
      txt <- sprintf("%s[['%s']][[j]][['%s']]", type, listname, name)
    } else {
      txt <- sprintf("%s[['%s']][[j]]", type, name)
    }
    if (inherits(input, "factor")) {
      levels <- sprintf("c({paste(levels(%s), collapse = ', ')})", txt)
    }
    if (l > 1) {
      if (inherits(input, "matrix")) {
        txt <- paste0(sprintf("matrix(c({paste(%s, collapse = ', ')}), ", txt),
                      sprintf("nrow = {nrow(%s)}, ", txt),
                      sprintf("ncol = {ncol(%s)})", txt))
      } else {
        txt <- sprintf("c({paste(%s, collapse = ', ')})", txt)
      }
    } else {
      txt <- sprintf("{%s}", txt)
    }
    if (inherits(input, "factor")) {
      txt <- sprintf("factor(%s, levels = %s)", txt, levels)
    }
  } else {
    if (inherits(input, "list")) {
      txt <- imap_chr(input, input_txt_one,
        islist = TRUE, listname = name, postfix = postfix
      )
      txt <- paste("list(", paste0(txt, collapse = ", "), ")", sep = "")
    }
    if (inherits(input, "function") || inherits(input, "lm")) {
      if ("print" %in% names(attributes(input))) {
        txt <- sprintf("{attr(%s[['%s']][[j]], 'print')}", type, name)
      } else {
        stop("For functions or models, a manually defined print attribute is needed.")
      }
    }
    if (!is.null(input) &&
        !inherits(input, "list") &&
        !inherits(input, "function") &&
        !inherits(input, "lm")) {
      browser()
    }
  }
  if (name != make.names(name)) {
    name <- paste0("`", name, "`")
  }
  if (!is.null(input)) {
    if (name != "...") {
      return(sprintf("%s = %s", name, txt))
    } else {
      return(txt)
    }
  } else {
    return("")
  }
}

input_txt_all <- function(input, postfix = NULL) {
  input_msg <- imap(input, input_txt_one, postfix = postfix)
  if (length(input_msg) > 1) {
    input_msg <- input_msg[map_lgl(input_msg, function(x) x != "")]
  }
  paste(input_msg, collapse = ", ")
}

#' @importFrom purrr map
get_msg_all <- function(input_msg, input_secondary_msg = NULL) {

  # How the function call appears
  call_msg <- paste("{label}(", input_msg, ")", sep = "")
  if (!is.null(input_secondary_msg)) {
    call_msg <- paste(call_msg, "(", input_secondary_msg, ")", sep = "")
  }
  exp_msg <- "the solution called with the same input"

  # Exception messages
  exception_msg_prefix <- paste0(
    "{label} is not correct: ",
    call_msg
  )
  exception_msg_postfix <- list(
    error_msg = " throws an error but should not.",
    error_msg2 = paste0(
      " throws the error \"{act_res$message}\" ",
      "instead of \"{exp_res$message}\"."
    ),
    noerror_msg = " does not throw an error but should.",
    warning_msg = " throws a warning but should not.",
    warning_msg2 = paste0(
      " throws the warning \"{act_res$message}\" ",
      "instead of \"{exp_res$message}\"."
    ),
    nowarning_msg = " does not throw a warning but should."
  )

  exception_msg <- exception_msg_postfix %>%
    map(function(x) paste0(exception_msg_prefix, x))

  return(list(
    act_msg = call_msg,
    exp_msg = exp_msg,
    act_out_msg = paste0(
      "testthat::capture_output_lines(",
      call_msg, ")"
    ),
    exp_out_msg = paste0(
      "testthat::capture_output_lines() of ",
      exp_msg
    ),
    exception_msg = exception_msg
  ))
}

get_call_all <- function(input, input_secondary = NULL, is_s3 = FALSE) {
  call_args <- names(input) %>%
    map_chr(function(x) {
      ifelse(x != "...",
        paste(x, " = input[['", x, "']][[j]]",
          sep = ""
        ),
        paste("input[['", x, "']][[j]]",
          sep = ""
        )
      )
    }) %>%
    paste(collapse = ", ")

  if (!is_s3) {
    call_act <- paste("act$val(", call_args, ")", sep = "")
    call_exp <- paste("exp$val(", call_args, ")", sep = "")
  } else {
    call_act <- paste("act$val(act$s3_ctor(", call_args, "))", sep = "")
    call_exp <- paste("exp$val(exp$s3_ctor(", call_args, "))", sep = "")
  }

  if (!is.null(input_secondary)) {
    call_args <- names(input_secondary) %>%
      map_chr(function(x) {
        ifelse(x != "...",
          paste(x, " = input_secondary[['", x,
            "']][[j]]",
            sep = ""
          ),
          paste("input_secondary[['", x, "']][[j]]",
            sep = ""
          )
        )
      }) %>%
      paste(collapse = ", ")
    call_act <- paste(call_act, "(", call_args, ")", sep = "")
    call_exp <- paste(call_exp, "(", call_args, ")", sep = "")
  }

  return(list(
    call_act = call_act,
    call_exp = call_exp
  ))
}

fix_null_calls <- function(calls, input, j, secondary = FALSE) {
  call_act_fixed <- calls$call_act
  call_exp_fixed <- calls$call_exp
  for (i in seq_along(input)) {
    if (is.null(input[[i]][[j]])) {
      if (!secondary) {
        nn <- glue("input[['{names(input)[i]}']][[j]]")
      } else {
        nn <- glue("input_secondary[['{names(input)[i]}']][[j]]")
      }
      n1 <- fixed(paste(",", nn))
      n2 <- fixed(paste(nn))
      call_act_fixed <- str_remove_all(call_act_fixed, n1)
      call_exp_fixed <- str_remove_all(call_exp_fixed, n1)
      call_act_fixed <- str_remove_all(call_act_fixed, n2)
      call_exp_fixed <- str_remove_all(call_exp_fixed, n2)
    }
  }
  return(list(
    call_act = call_act_fixed,
    call_exp = call_exp_fixed
  ))
}

capture_all <- function(call, n = 1) {
  out <- capture_output_lines({
    res <- tryCatch(
      expr = eval.parent(parse(text = call), n),
      error = function(e) e,
      warning = function(w) w
    )
  })
  return(list(
    out = out,
    res = res
  ))
}

expect_exception <- function(act_res, exp_res, label, j, msg, input,
                             input_secondary = NULL) {
  msg <- msg$exception_msg

  if (inherits(exp_res, "error")) {
    expect(inherits(act_res, "error"), glue(msg$noerror_msg))
    if (inherits(act_res, "error")) {
      expect(act_res$message == exp_res$message, glue(msg$error_msg2))
    }
    return(TRUE)
  } else {
    is_correct <- expect(!inherits(act_res, "error"), glue(msg$error_msg))
    if (inherits(is_correct, "expectation_failure")) {
      return(TRUE)
    }
  }
  if (inherits(exp_res, "warning")) {
    expect(inherits(act_res, "warning"), glue(msg$nowarning_msg))
    if (inherits(act_res, "warning")) {
      expect(act_res$message == exp_res$message, glue(msg$warning_msg2))
    }
    return(TRUE)
  } else {
    is_correct <- expect(!inherits(act_res, "warning"), glue(msg$warning_msg))
    if (inherits(is_correct, "expectation_failure")) {
      return(TRUE)
    }
  }
  return(FALSE)
}

format_input <- function(input, j) {
  for (i in seq_along(input)) {
    if (is_atomic(input[[i]][[j]]) && is_character(input[[i]][[j]])) {
      input[[i]][[j]] <- paste("\"", input[[i]][[j]], "\"", sep = "")
    }
    if (inherits(input[[i]][[j]], "list")) {
      for (k in seq_along(input[[i]][[j]])) {
        if (is_atomic(input[[i]][[j]][[k]]) &&
          is_character(input[[i]][[j]][[k]])) {
          input[[i]][[j]][[k]] <- paste("\"", input[[i]][[j]][[k]], "\"", sep = "")
          browser()
        }
      }
    }
    if (inherits(input[[i]][[j]], "data.frame")) {
      # TODO
      browser()
    }
    if (inherits(input[[i]][[j]], "function")) {
      if (!("print" %in% names(attributes(input[[i]][[j]])))) {
        browser()
      }
      # TODO
    }
  }
  input
}

#' @importFrom sloop is_s3_generic is_s3_method
ftype_s3_status <- function(f, env, fname) {
  gen <- is_s3_generic(fname, env)
  mth <- is_s3_method(fname, env)
  if (!gen & !mth) {
    "function"
  }
  else {
    c("S3", if (gen) "generic", if (mth) "method")
  }
}

#' @importFrom sloop ftype
#' @importFrom testthat capture_warning
ftype_in_env <- function(f, env, fname = NULL) {
  warn <- capture_warning(res <- ftype(f))
  if (exists("res") && length(res) == 1 && res == "function") {
    warn <- capture_warning(res <- ftype_s3_status(f, env, fname))
  } else {
    warn <- capture_warning(res <- ftype_s3_status(f, env, fname))
  }
  if (!exists("res")) {
    return("function")
  } else {
    return(res)
  }
}
