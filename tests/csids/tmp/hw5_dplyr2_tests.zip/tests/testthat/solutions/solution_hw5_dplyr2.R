## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

nations <- read_csv("/course/data/nations.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

longevity <- nations %>%
  filter(year == 2016 & !is.na(life_expect) & !is.na(gdp_percap)) %>%
  dplyr::select(country, gdp_percap, life_expect, population, region)

## Do not modify this line! ## Write your code for 3. after this line! ##

ea_na_75_85 <- longevity %>%
  filter(life_expect >= 75 & life_expect <= 85 &
    (region %in% c("East Asia & Pacific", "North America"))) %>%
  arrange(desc(life_expect))

## Do not modify this line! ## Write your code for 4. after this line! ##

top_10_perc_us <- longevity %>%
  mutate(perc_rank = percent_rank(life_expect)) %>%
  arrange(desc(perc_rank)) %>%
  filter(perc_rank >= 0.9 | country == "United States")

## Do not modify this line! ## Write your code for 5. after this line! ##

gdp_by_region <- nations %>%
  mutate(gdp = gdp_percap * population) %>%
  group_by(region, year) %>%
  summarize(total_gdp = sum(gdp, na.rm = TRUE) / 1000000000000)

## Do not modify this line! ## Write your code for 6. after this line! ##

p_countries <- nations %>%
  filter(year == 2016) %>%
  group_by(income) %>%
  summarize(p = sum(life_expect > 70, na.rm = TRUE) / n())

