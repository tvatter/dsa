## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

airquality <- as_tibble(airquality)

## Do not modify this line! ## Write your code for 2. after this line! ##

airquality_replace_na <- airquality %>%
  replace_na(list(Ozone = mean(.$Ozone, na.rm = TRUE)))

## Do not modify this line! ## Write your code for 3. after this line! ##

airquality_remove_na <- airquality_replace_na %>%
  drop_na(Solar.R)

## Do not modify this line! ## Write your code for 4. after this line! ##

airquality_selected <- airquality_remove_na %>%
  dplyr::select(Wind, Temp, Month, Day)

## Do not modify this line! ## Write your code for 5. after this line! ##

airquality_filtered <- airquality_selected %>%
  filter(Month > 6)

## Do not modify this line! ## Write your code for 6. after this line! ##

airquality_wind <- airquality_filtered %>%
  mutate(Wind = case_when(
    Wind >= 1 & Wind < 9 ~ 7.4,
    Wind >= 9 & Wind < 20 ~ 11.5,
    TRUE ~ 21
  ))

## Do not modify this line! ## Write your code for 7. after this line! ##

airquality_temp <- airquality_wind %>%
  mutate(Temp = (Temp - 32) * 5 / 9)

## Do not modify this line! ## Write your code for 8. after this line! ##

airquality_mean_temp <- airquality_temp %>%
  group_by(Month) %>%
  summarize(mean_temp = mean(Temp))

