## Number of exercises
n_ex <- 8

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw5_dplyr3.R", n_ex)
file.remove("solutions/solution_hw5_dplyr3.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw5_dplyr3.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})

to_test <- list(
  "airquality",
  "airquality_replace_na",
  "airquality_remove_na",
  "airquality_selected",
  "airquality_filtered",
  "airquality_wind",
  "airquality_temp",
  "airquality_mean_temp"
) %>%
  rapply(test_object, how = "replace", tolerance = 1e-6)

options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(
  list("as_tibble"),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
packages <- c(
  list("tidyverse"),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
