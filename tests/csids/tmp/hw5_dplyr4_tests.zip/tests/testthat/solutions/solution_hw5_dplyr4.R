## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

data("billboard")

## Do not modify this line! ## Write your code for 2. after this line! ##

t1 <- billboard %>%
  pivot_longer(
    cols = starts_with("wk"),
    names_to = "week",
    values_to = "rank"
  )

## Do not modify this line! ## Write your code for 3. after this line! ##

t2 <- billboard %>%
  pivot_longer(
    cols = starts_with("wk"),
    names_to = "week",
    names_prefix = "wk",
    values_to = "rank",
    values_drop_na = TRUE
  )

## Do not modify this line! ## Write your code for 4. after this line! ##

t2_rank <- t2 %>%
  mutate(rank_increase = lag(rank) - rank) %>%
  filter(week != "1") %>%
  group_by(artist, track, date.entered) %>%
  summarize(highest_rank_increase = max(rank_increase)) %>%
  arrange(desc(highest_rank_increase))

## Do not modify this line! ## Write your code for 5. after this line! ##

t3 <- t2 %>%
  separate(col = "date.entered", c("year", "month", "date"), sep = "[-]")

## Do not modify this line! ## Write your code for 6. after this line! ##

t4 <- t3 %>%
  group_by(artist, track, month) %>%
  summarize(highest_rank = min(rank))

## Do not modify this line! ## Write your code for 7. after this line! ##

t5 <- billboard %>%
  filter(!is.na(wk1)) %>%
  arrange(wk1) %>%
  dplyr::select(artist, track, date.entered, wk1_rank = wk1)

## Do not modify this line! ## Write your code for 8. after this line! ##

t6 <- t1 %>%
  mutate(year.entered = substr(date.entered, 1, 4)) %>%
  filter(year.entered == "2000") %>%
  group_by(artist) %>%
  summarize(avg_rank = mean(rank, na.rm = TRUE))

