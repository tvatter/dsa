## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

trips <- read_csv("/course/data/citybike.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

trips <- rename_all(trips, function(x) str_replace_all(x, " ", "_"))

## Do not modify this line! ## Write your code for 3. after this line! ##

years <- trips %>%
  summarize(
    min_birth_year = min(birth_year, na.rm = TRUE),
    max_birth_year = max(birth_year, na.rm = TRUE)
  )

## Do not modify this line! ## Write your code for 4. after this line! ##

broadway <- trips %>%
  filter(str_detect(start_station_name, "Broadway") |
    str_detect(end_station_name, "Broadway"))

## Do not modify this line! ## Write your code for 5. after this line! ##

trips_counts <- trips %>%
  group_by(start_station_name, end_station_name) %>%
  summarize(count = n())

## Do not modify this line! ## Write your code for 6. after this line! ##

frequent_trips <- trips_counts %>%
  arrange(desc(count)) %>%
  head(10)

