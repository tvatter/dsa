## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

airbnb <- read_csv("/course/data/airbnb.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

nyc_price <- airbnb %>%
  drop_na() %>%
  group_by(neighbourhood) %>%
  summarize(avg_price = mean(price)) %>%
  mutate(price_rank = percent_rank(avg_price))

## Do not modify this line! ## Write your code for 3. after this line! ##

nyc_10percent <- nyc_price %>%
  filter(price_rank > 0.9) %>%
  arrange(neighbourhood)

## Do not modify this line! ## Write your code for 4. after this line! ##

by_type <- airbnb %>%
  group_by(room_type) %>%
  dplyr::select(price, availability_365) %>%
  summarize_if(is.numeric, median, na.rm = TRUE)

## Do not modify this line! ## Write your code for 5. after this line! ##

neighbourhood_room <- airbnb %>%
  group_by(neighbourhood_group, room_type) %>%
  count(name = "count") %>%
  group_by(neighbourhood_group) %>%
  mutate(prop = count / sum(count))

## Do not modify this line! ## Write your code for 6. after this line! ##

neighbourhood_room_wider <- neighbourhood_room %>%
  dplyr::select(-count) %>%
  pivot_wider(
    names_from = "room_type",
    values_from = "prop"
  )

