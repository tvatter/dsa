## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

data(msleep)

## Do not modify this line! ## Write your code for 2. after this line! ##

vore_prop <- msleep %>%
  count(vore, name = "count") %>%
  mutate(prop = count / sum(count))

## Do not modify this line! ## Write your code for 3. after this line! ##

vore_means <- msleep %>%
  group_by(vore) %>%
  summarize_if(is.numeric, mean, na.rm = TRUE)

## Do not modify this line! ## Write your code for 4. after this line! ##

primate <- msleep %>%
  filter(order == "Primates")

## Do not modify this line! ## Write your code for 5. after this line! ##

brain_primate <- primate %>%
  drop_na(brainwt) %>%
  mutate(brain_pro = brainwt / bodywt) %>%
  dplyr::select(
    name, genus, brain_pro,
    dplyr::matches("wt"), starts_with("sleep")
  )

