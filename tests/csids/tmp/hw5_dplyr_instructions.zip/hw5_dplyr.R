# HW5: dplyr
#
# Do NOT use a `for`, `while`, or `repeat` loop!
# Whenever using `select()`, make sure to write `dplyr::select()` to avoid
# conflicts with other packages.
#
# 1. Load the `tidyverse` package and use `read_csv` to load
#    `/course/data/abalone.csv` and assign it to a tibble `abalone`.
#
#    To check your answer:
#
#    The output of `print(abalone, n = 5)` is
#
#    ```
#    # A tibble: 4,177 x 10
#          X sex   length diameter height whole_weight shucked_weight
#      <dbl> <chr>  <dbl>    <dbl>  <dbl>        <dbl>          <dbl>
#    1     1 M      0.455    0.365  0.095        0.514         0.224
#    2     2 M      0.35     0.265  0.09         0.226         0.0995
#    3     3 F      0.53     0.42   0.135        0.677         0.256
#    4     4 M      0.44     0.365  0.125        0.516         0.216
#    5     5 I      0.33     0.255  0.08         0.205         0.0895
#    # … with 4,172 more rows, and 3 more variables: viscera_weight <dbl>,
#    #   shell_weight <dbl>, rings <dbl>
#    ```
#
## Do not modify this line!



# 2. Extract a tibble `length_sex_ring` which contains the `sex`, `diameter`,
#    `height` and `rings` columns. The dataset should be filtered for
#    length strictly larger than 0.6 and be sorted by increasing `sex` and
#    decreasing `ring`.
#    To do that, you can use
#      - `filter` to select rows that have `length` larger than 0.6,
#      - `arrange` to arrange data set by sex with first `"F"` then `"I"`
#        and `"M"`, and descending order of `ring`,
#      - `dplyr::select` to select columns `sex`, `diameter`, `height` and
#        `rings`.
#    Note: by doing `dplyr::`, we enforce the use of `dplyr`'s `select` to
#    resolve function conflicts with other packages such as `MASS`.
#
#    To check your answer:
#
#    The output of `print(length_sex_ring, n = 5)` is
#
#    ```
#    # A tibble: 1,216 x 4
#      sex   diameter height rings
#      <chr>    <dbl>  <dbl> <dbl>
#    1 F        0.585  0.185    29
#    2 F        0.49   0.215    25
#    3 F        0.54   0.215    24
#    4 F        0.47   0.2      23
#    5 F        0.52   0.225    23
#    # … with 1,211 more rows
#    ```
#
## Do not modify this line!



# 3. Extract a tibble `count_prop` of dimension 3 x 3,
#    which contains the `sex`, `count` and `prop` columns.
#    The dataset should be grouped by increasing `sex` with counted numbers
#    of each group. Then calculate the proportion of each count.
#    To do that, you can use
#      - `count` to count observations by `sex` (set the `name` argument
#        as `"count"`),
#      - `mutate` to make a new column containing the poportion per sex
#        (i.e., `count / sum(count)`) and name it `prop`.
#
#    To check your answer:
#
#    The output of `print(count_prop, n = 5)` is
#
#    ```
#    # A tibble: 3 x 3
#      sex   count  prop
#      <chr> <int> <dbl>
#    1 F      1307 0.313
#    2 I      1342 0.321
#    3 M      1528 0.366
#    ```
#
## Do not modify this line!



# 4. Extract a tibble `mean_max_min` of dimension 3 x 4, which contains the
#    `sex`, `weight_mean`, `weight_max` and `weight_min` columns.
#    The dataset should be grouped by increasing `sex` and summarized by
#    finding mean, max and min of `shucked_weight`.
#    To do that, you can use
#      - `group_by` to group data set by `sex`,
#      - `summarize` to to collapse all values into three new columns:
#        `weight_mean`, `weight_max` and `weight_min`, where
#          - `weight_mean` should be the mean of `shucked_weight`,
#          - `weight_min` should be min of `shucked_weight`,
#          - `weight_max` should be max of `shucked_weight`.
#
#    To check your answer:
#
#    The output of `print(mean_max_min, n = 5)` is
#
#    ```
#    # A tibble: 3 x 4
#      sex   weight_mean weight_max weight_min
#      <chr>       <dbl>      <dbl>      <dbl>
#    1 F           0.446      1.49      0.031
#    2 I           0.191      0.774     0.001
#    3 M           0.433      1.35      0.0065
#    ```
#
## Do not modify this line!



# 5. Extract a tibble `filter_na` of dimension 2938 x 10,
#    which contains all columns. The dataset should be filtered for diameter
#    equal to `NA` or strictly greater than 0.36. The column `X` should be
#    renamed as `index` and you should also reorder the columns such that
#    `index`, `sex`, `length`, `diameter` and `rings` come first and then
#    the other columns appear in their original order.
#    To do that, you can use
#      - `filter` to select rows such that `diameter` is `NA` or greater
#         than 0.36,
#      - `rename` to rename `X` as `index`,
#      - `select` and `everything` to select all columns with first five
#        columns as `index`, `sex`, `length`, `diameter` and `rings`.
#
#    To check your answer:
#
#    The output of `print(filter_na, n = 5)` is
#
#    ```
#    # A tibble: 2,938 x 10
#      index sex   length diameter rings height whole_weight shucked_weight
#      <dbl> <chr>  <dbl>    <dbl> <dbl>  <dbl>        <dbl>          <dbl>
#    1     1 M      0.455    0.365    15  0.095        0.514          0.224
#    2     3 F      0.53     0.42      9  0.135        0.677          0.256
#    3     4 M      0.44     0.365    10  0.125        0.516          0.216
#    4     7 F      0.53     0.415    20  0.15         0.778          0.237
#    5     8 F      0.545    0.425    16  0.125        0.768          0.294
#    # … with 2,933 more rows, and 2 more variables: viscera_weight <dbl>,
#    #   shell_weight <dbl>
#    ```
#
## Do not modify this line!



# 6. Extract a tibble `transmute_abalone` of dimension 4177 x 2,
#    which contains the `whole_weight_in_mg` and `water_weight_in_mg` columns,
#    corresponding respectively to the whole weight and water weight in
#    milligrams.
#    To do that, you can use
#      - `transmute` to only keep two variables `whole_weight_in_mg` and
#        `water_weight_in_mg`, where
#          - `whole_weight_in_mg` is `whole_weight` times 1000,
#          - `water_weight_in_mg` is `whole_weight` minus all the other
#            weights times 1000.
#    Alternatively, you can do the same in two steps using `mutate` and then
#    `select`.
#
#    To check your answer:
#
#    The output of `print(transmute_abalone, n = 5)` is
#
#    ```
#    # A tibble: 4,177 x 2
#      whole_weight_in_mg water_weight_in_mg
#                   <dbl>              <dbl>
#    1               514               38.5
#    2               226.               7.50
#    3               677               69.
#    4               516               31.5
#    5               205               21.0
#    # … with 4,172 more rows
#    ```
#
## Do not modify this line!



# 7. Extract a tibble `first_1000_rank` of dimension 1000 x 3,
#    which contains the `diameter`, `rings` and `rings_rank` columns, sorted
#    by ascending `rings_rank`, which is a column containing the rank
#    corresponding to the value of the `rings` variable.
#    Then, select the three columns and rank on the `rings` and
#    filter for the rows corresponding to the first 1000 `rings_rank`.
#    To do that, you can use
#      - `select` to select `diameter` and `rings`,
#      - `mutate` and `row_number` to create a column `rings_rank`
#        corresponding to the ranks of the corresponding `rings`,
#      - `filter` to filter the rows such that `rings_rank` is less than or
#        equal to `1000`,
#      - `arrange` by `rings_rank`.
#
#    To check your answer:
#
#    The output of `print(first_1000_rank, n = 5)` is
#
#    ```
#    # A tibble: 1,000 x 3
#      diameter rings rings_rank
#         <dbl> <dbl>      <int>
#    1    0.055     1          1
#    2    0.1       2          2
#    3    0.1       3          3
#    4    0.09      3          4
#    5    0.12      3          5
#    # … with 995 more rows
#    ```
#
## Do not modify this line!



# 8. Extract a tibble `n_distinct_rings_by_sex` of dimension 3 x 2,
#    which contains the `sex` and `distinct_rings` columns.
#    The dataset should be grouped by `sex` and then summarized to
#    count distinct rings in each group.
#    To do that, you can use
#      - `group_by` to group data set by `sex`,
#      - `summarize` and `n_distinct` to build a new column called
#        `distinct_rings` counting the number of distinct rings of each group.
#
#    To check your answer:
#
#    The output of `print(n_distinct_rings_by_sex, n = 5)` is
#
#    ```
#    # A tibble: 3 x 2
#      sex   distinct_rings
#      <chr>          <int>
#    1 F                 23
#    2 I                 21
#    3 M                 24
#    ```
## Do not modify this line!




