## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
select <- dplyr::select

abalone <- read_csv("/course/data/abalone.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

length_sex_ring <- abalone %>%
  filter(length > 0.6) %>%
  arrange(sex, desc(rings)) %>%
  select(sex, diameter, height, rings)

## Do not modify this line! ## Write your code for 3. after this line! ##

count_prop <- abalone %>%
  count(sex, name = "count") %>%
  mutate(prop = count / sum(count))

## Do not modify this line! ## Write your code for 4. after this line! ##

mean_max_min <- abalone %>%
  group_by(sex) %>%
  summarize(
    weight_mean = mean(shucked_weight),
    weight_max = max(shucked_weight),
    weight_min = min(shucked_weight)
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

filter_na <- abalone %>%
  filter(is.na(diameter) | diameter > 0.36) %>%
  rename(index = X) %>%
  select(index, sex, length, diameter, rings, everything())

## Do not modify this line! ## Write your code for 6. after this line! ##

transmute_abalone <- abalone %>%
  transmute(
    whole_weight_in_mg = whole_weight * 1000,
    water_weight_in_mg = (whole_weight - shucked_weight
      - viscera_weight - shell_weight) * 1000
  )

## Do not modify this line! ## Write your code for 7. after this line! ##

first_1000_rank <- abalone %>%
  select(diameter, rings) %>%
  mutate(rings_rank = row_number(rings)) %>%
  filter(rings_rank <= 1000) %>%
  arrange(rings_rank)

## Do not modify this line! ## Write your code for 8. after this line! ##

n_distinct_rings_by_sex <- abalone %>%
  group_by(sex) %>%
  summarize(distinct_rings = n_distinct(rings))

