## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

activities <- read_csv("/course/data/activities.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

act_longer <- activities %>%
  pivot_longer(c(-id, -trt), names_to = "var", values_to = "score")

## Do not modify this line! ## Write your code for 3. after this line! ##

act_separated <- act_longer %>%
  separate(col = "var", into = c("action", "time"))

## Do not modify this line! ## Write your code for 4. after this line! ##

act_wider <- act_separated %>%
  pivot_wider(names_from = "action", values_from = "score")

## Do not modify this line! ## Write your code for 5. after this line! ##

col_ix <- which(is.na(act_wider), arr.ind = TRUE)[2]

## Do not modify this line! ## Write your code for 6. after this line! ##

act_filled <- act_wider %>%
  fill(col_ix, .direction = "up")

