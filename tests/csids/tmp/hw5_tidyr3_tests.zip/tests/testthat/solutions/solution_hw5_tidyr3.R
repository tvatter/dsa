## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

warpbreaks <- read_csv("/course/data/warpbreaks.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

t1 <- warpbreaks %>%
  drop_na() %>%
  filter(
    wool %in% c("A", "B"),
    tension %in% c("L", "M", "H"),
    breaks <= 100, breaks >= 0
  ) %>%
  dplyr::select(wool, tension, breaks) %>%
  as_tibble()

## Do not modify this line! ## Write your code for 3. after this line! ##

t2 <- t1 %>%
  count(wool, tension)

## Do not modify this line! ## Write your code for 4. after this line! ##

t3 <- t1 %>%
  pivot_wider(
    names_from = tension,
    values_from = breaks,
    values_fn = list(breaks = sum)
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

t4 <- t3 %>%
  pivot_longer(
    cols = c("L", "M", "H"),
    names_to = "tension",
    values_to = "sum_of_breaks"
  )

