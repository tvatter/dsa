## Number of exercises
n_ex <- 5

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw5_tidyr3.R", n_ex)
file.remove("solutions/solution_hw5_tidyr3.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw5_tidyr3.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})

to_test <- list(
  "warpbreaks",
  "t1",
  "t2",
  "t3",
  "t4"
) %>%
  rapply(test_object, how = "replace", tolerance = 1e-6)

options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(list("read_csv"), replicate(n_ex - 1, NA, simplify = FALSE))
packages <- c(
  list("tidyverse"),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
