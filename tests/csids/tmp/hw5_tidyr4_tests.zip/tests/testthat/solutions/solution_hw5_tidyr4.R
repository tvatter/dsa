## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

mobility <- read_csv("/course/data/mobility.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

count_by_state <- mobility %>%
  group_by(State) %>%
  count() %>%
  arrange(State)

## Do not modify this line! ## Write your code for 3. after this line! ##

stats_by_state <- mobility %>%
  group_by(State) %>%
  summarize_at(c("Commute", "Mobility"), list(mean = mean, sd = sd))

## Do not modify this line! ## Write your code for 4. after this line! ##

stats_by_state_longer <- stats_by_state %>%
  pivot_longer(-State, values_to = "Value") %>%
  separate(name, into = c("Variable", "Stat"), sep = "_")

## Do not modify this line! ## Write your code for 5. after this line! ##

stats_by_state_ranked <- stats_by_state_longer %>%
  filter(Stat == "mean") %>%
  dplyr::select(-Stat) %>%
  group_by(Variable) %>%
  mutate(Value = percent_rank(Value)) %>%
  pivot_wider(names_from = "Variable", values_from = "Value") %>%
  arrange(desc(Commute), desc(Mobility))

## Do not modify this line! ## Write your code for 6. after this line! ##

coordinates <- mobility %>%
  group_by(State) %>%
  summarize(
    Latitude = round(mean(Latitude), 3),
    Longitude = round(mean(Longitude), 2)
  ) %>%
  unite("Coordinates", Latitude:Longitude)

