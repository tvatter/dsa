## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

iris <- as_tibble(iris)

## Do not modify this line! ## Write your code for 2. after this line! ##

summary_iris <- summary(iris)

## Do not modify this line! ## Write your code for 3. after this line! ##

species_count <- iris %>% count(Species, name = "num")

## Do not modify this line! ## Write your code for 4. after this line! ##

summary_stats <- iris %>%
  summarize_if(
    is.numeric,
    c(
      "Min." = min,
      "1st Qu." = function(x) quantile(x, 0.25, na.rm = TRUE),
      "Median" = median,
      "Mean" = mean,
      "3rd Qu." = function(x) quantile(x, 0.75, na.rm = TRUE),
      "Max." = max
    )
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

summary_long <- summary_stats %>%
  pivot_longer(everything()) %>%
  separate(name, c("variable", "stat"), sep = "_")

## Do not modify this line! ## Write your code for 6. after this line! ##

summary_stats_tidy <- summary_long %>%
  pivot_wider(names_from = stat, values_from = value)

## Do not modify this line! ## Write your code for 7. after this line! ##

summary_stats_transposed <- summary_stats_tidy %>%
  pivot_longer(-variable, names_to = "Stat", values_to = "value") %>%
  pivot_wider(names_from = variable, values_from = value)

