## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

fu <- read_csv("/course/data/football.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

fu_separated <- separate(fu, "date", c("year", "mon", "day"), sep = "[-]+")

## Do not modify this line! ## Write your code for 3. after this line! ##

fu_tidy <- fu_separated %>%
  pivot_longer(home_team:away_team, names_to = "team_type", values_to = "team")

## Do not modify this line! ## Write your code for 4. after this line! ##

fu_team <- fu_tidy %>%
  mutate(
    scored = if_else(team_type == "home_team", home_score, away_score),
    conceded = if_else(team_type == "home_team", away_score, home_score),
    gd = scored - conceded
  ) %>%
  dplyr::select(year:day, scored:gd, team, city, country)

## Do not modify this line! ## Write your code for 5. after this line! ##

fu_city <- fu_team %>%
  unite("place", city:country)

## Do not modify this line! ## Write your code for 6. after this line! ##

fu_england <- fu_city %>%
  filter(team == "England") %>%
  group_by(year) %>%
  summarize_if(is.numeric, mean, na.rm = TRUE) %>%
  arrange(desc(gd), desc(scored), conceded)

