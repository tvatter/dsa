## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)

useR2016 <- read_csv("/course/data/useR2016.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

t1 <- useR2016 %>%
  dplyr::select(Q2:Q13_F, -Q12, Q25)

## Do not modify this line! ## Write your code for 3. after this line! ##

t1_longer <- t1 %>%
  pivot_longer(Q13:Q13_F,
    names_to = "cases",
    values_to = "comments",
    values_drop_na = TRUE
  )

## Do not modify this line! ## Write your code for 4. after this line! ##

t1_longer_rename <- t1_longer %>%
  rename(
    sex = Q2,
    age = Q3,
    degree = Q7,
    academic_status = Q8,
    experience = Q11,
    value = Q25
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

separate_drop_redundant <- t1_longer_rename %>%
  separate(cases,
    into = c("case_name", "category"),
    sep = "_",
    fill = "right"
  ) %>%
  replace_na(list(category = "A")) %>%
  dplyr::select(-case_name)

## Do not modify this line! ## Write your code for 6. after this line! ##

filter_na_unite <- separate_drop_redundant %>%
  filter(!is.na(age), !is.na(experience)) %>%
  unite(age_and_experience, age, experience, sep = " && ")

## Do not modify this line! ## Write your code for 7. after this line! ##

first_100_rank <- filter_na_unite %>%
  mutate(row_number = row_number(value)) %>%
  filter(row_number <= 100)

## Do not modify this line! ## Write your code for 8. after this line! ##

experience_percentage <- t1_longer_rename %>%
  drop_na() %>%
  group_by(sex) %>%
  count(experience, name = "count") %>%
  mutate(count = count / sum(count) * 100) %>%
  pivot_wider(names_from = "experience", values_from = "count")

