#' Extract the code chunks from the scaffold
#'
#' Generates an error if the code in `file` does not have `n_chunks`.
#'
#' @param file The path where the source code is.
#' @param n_chunks The number of chunks to extract.
#' @importFrom readr read_lines
#' @importFrom stringr str_starts str_replace_all str_trim
#' @importFrom magrittr %>%
#' @export
extract_chunks <- function(file, n_chunks) {
  source_lines <- read_lines(file)
  n_lines <- length(source_lines)
  chunks_starts <- which(str_starts(source_lines, "## Do not modify this line!"))

  if (length(chunks_starts) != n_chunks) {
    stop("One of the 'do not modify this line!' lines has been modified, exiting.")
  }

  # If we extract zero chunk, then just return as is
  chunks <- rep("", n_chunks)
  if (n_chunks == 0) {
    return(chunks)
  }

  # Fill chunks 1 to n_chunks - 1
  for (i in seq_along(chunks)[-n_chunks]) {
    chunk_start <- chunks_starts[i] + 1
    if (chunk_start != chunks_starts[i + 1]) { # To deal with empty chunks
      chunk_end <- chunks_starts[i + 1] - 1
      chunks[i] <- source_lines[chunk_start:chunk_end] %>%
        str_replace_all(pattern = "#[^\\\n]*", replacement = "") %>%
        str_trim() %>%
        paste0(collapse = "\n")
    }
  }

  # Fill the last chunk if necessary
  if (n_chunks > 1 && chunks_starts[n_chunks] != n_lines) {
    chunks[n_chunks] <- paste0(source_lines[(chunks_starts[n_chunks] + 1):n_lines], collapse = "\n")
  }

  return(chunks)
}

#' Evaluate a chunk of code in a given environment
#'
#' Basically a wrapper around `eval`
#'
#' @param chunk The chunk of code.
#' @param env The environment in which to evaluate `chunk`.
#' @importFrom rlang caller_env
#' @export
eval_chunk <- function(chunk, env = caller_env()) {
  if (!(chunk %in% c("", "\n"))) {
    eval(parse(text = chunk), envir = env)
  }
}

#' Evaluate the chunks and test for the relevant variables
#'
#' A basic testing framework allowing to automatize the writing of
#' unit tests.
#'
#' @param submission_chunks The submission chunks of code.
#' @param solution_chunks The solution chunks of code.
#' @param submission The submission environment.
#' @param solution The solution environment.
#' @param to_test A list of length equal to the number of code chunks.
#' Each element is then either an object of class `test_object` (in case the
#' corresponding exercise's part tests a single object), or a sublist of
#' `test_object` (in case one wants to test multiple objects).
#' @param seeds A list of seeds to reset at each step (`NA` indicates no reset).
#' @param functions A list of function names to test at each step
#'                  (`NA` indicates nothing to test).
#' @param forbidden A list of forbidden function names to test at each step
#'                  (`NA` indicates nothing to test).
#' @param packages A list of packages names to test at each step
#'                  (`NA` indicates nothing to test).
#' @param output A logical vector to indicate if the output of the
#'               execution should be compared.
#' @importFrom testthat test_that
#' @importFrom purrr walk
#' @export
test_exercise <- function(submission_chunks, solution_chunks,
                          submission, solution, to_test,
                          seeds = NULL,
                          functions = NULL,
                          forbidden = NULL,
                          packages = NULL,
                          output = NULL) {

  # sanity checks
  nex <- length(submission_chunks)
  expect_length(to_test, nex)
  if (!is.null(seeds)) {
    expect_length(seeds, nex)
  }
  if (!is.null(functions)) {
    expect_length(functions, nex)
  }
  if (!is.null(forbidden)) {
    expect_length(forbidden, nex)
  }
  if (!is.null(packages)) {
    expect_length(packages, nex)
  }
  if (!is.null(output)) {
    expect_length(output, nex)
  }


  for (j in seq_along(submission_chunks)) {
    test_that(glue("Checking part {j}"), {

      # test whether the appropriate functions have been used
      if (!is.null(functions) && !any(is.na(functions[[j]]))) {
        for (i in seq_along(functions[[j]])) {
          expect_function(submission_chunks[j], functions[[j]][[i]])
        }
      }

      # test whether the forbidden functions have not been used
      if (!is.null(forbidden) && !any(is.na(forbidden[[j]]))) {
        for (i in seq_along(forbidden[[j]])) {
          expect_function(submission_chunks[j], forbidden[[j]][[i]], FALSE)
        }
      }

      # evaluate the submission chunk in its environment
      out_submission <- capture_output_lines(eval_chunk(
        submission_chunks[j],
        submission
      ))

      # test whether the appropriate packages have been loaded
      if (!is.null(packages) && !any(is.na(packages[[j]]))) {
        for (i in seq_along(packages[[j]])) {
          expect_package(submission, packages[[j]][[i]])
        }
      }

      # reset the seed if necessary and
      # evaluate the solution chunk in its environment
      if (!is.null(seeds) && !is.na(seeds[[j]])) {
        set.seed(seeds[[j]])
      }
      out_solution <- capture_output_lines(eval_chunk(
        solution_chunks[j],
        solution
      ))

      if (!is.null(output) && output[[j]]) {
        expect_equivalent_default(out_submission, out_solution,
          label = "testthat::capture_output_lines(code)",
          label_exp = "testthat::capture_output_lines(code_solution)"
        )
      }

      # test for existence and correctness of all relevant objects
      if (length(to_test[[j]]) == 1) {
        expect_object(submission = submission, solution = solution, to_test[[j]])
      } else {
        walk(to_test[[j]], expect_object,
          submission = submission, solution = solution
        )
      }
    })
  }
}

#' @importFrom testthat capture_condition
#' @importFrom purrr map_chr
#' @importFrom stringr str_wrap
#' @importFrom utils capture.output
example_to_write <- function(examples, envir = parent.frame()) {
  c(
    "\nTo check your answer:",
    purrr::map_chr(examples, function(x) {
      capture.output(condition <- testthat::capture_condition(
        eval(parse(text = x),
          envir = envir
        )
      ))
      if (inherits(condition, "message")) {
        condition$message <- condition$message
      }
      if (inherits(condition, "warning")) {
        txt <- paste(
          "Warning message: In",
          capture.output(print(condition$call)),
          ":", condition$message
        )
      }
      if (inherits(condition, "error")) {
        txt <- stringr::str_remove_all(
          as.character(condition),
          stringr::fixed("\n")
        )
      }

      if (!inherits_any(condition, c("error", "warning"))) {
        txt <- testthat::capture_output(eval(parse(text = x),
          envir = envir
        ))
        if (!is.null(condition) &&
          !inherits(condition, "lifecycle_soft_deprecated")) {
          txt <- paste0(condition$message, txt, collapse = "\n ")
        }
      } else {
        txt <- txt %>% str_wrap(70, exdent = 1)
      }

      txt <- str_replace_all(txt, fixed("`"), fixed(" "))
      paste(glue::glue("\n\nThe output of `{x}` is"),
        paste0("```\n", txt, "\n```"),
        sep = "\n\n"
      )
    })
  )
}

#' Custom ggsave for output that looks nice in Ed
#'
#' @param object ggplot object to save
#' @param label Used to customise the filname
#' @param width Plot width in units ("in", "cm", or "mm")
#' @param height Plot height in units ("in", "cm", or "mm")
#' @param ... Additional arguments for `ggplot2::ggsave`
#' @importFrom ggplot2 ggsave
#' @export
my_ggsave <- function(object,
                      label = NULL,
                      width = 8.14,
                      height = 6,
                      ...) {
  act <- quasi_label(enquo(object), label, arg = "object")

  pars <- list(
    filename = glue("{str_remove_all(act$lab, '`')}.png"),
    plot = act$val,
    width = width,
    height = height
  )
  pars <- modifyList(pars, list(...))
  do.call(ggsave, pars)
}
