## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
trips <- read_csv("/course/data/citybike.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

trips_with_genders <- trips %>%
  mutate(gender = factor(gender, labels = c("Unknown", "Male", "Female"))) %>%
  dplyr::select(gender, everything())

## Do not modify this line! ## Write your code for 3. after this line! ##

trips_with_dates <- trips %>%
  mutate(
    starttime = mdy_hms(starttime),
    stoptime = mdy_hms(stoptime),
    interval = starttime %--% stoptime
  ) %>%
  dplyr::select(starttime, stoptime, interval, everything())

## Do not modify this line! ## Write your code for 4. after this line! ##

trips_start_times <- trips_with_dates %>%
  dplyr::select(starttime) %>%
  mutate(
    start_ymd = floor_date(starttime, "day"),
    start_hour = hour(starttime)
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

trips_per_hour <- trips_start_times %>%
  group_by(start_hour) %>%
  summarize(
    num_trips = n(),
    num_days = n_distinct(start_ymd),
    mean_trips = num_trips / num_days
  )

