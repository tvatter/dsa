## Do not modify this line! ## Your code for 1.

library(tidyverse)
library(lubridate)
theme_set(theme_light())
email <- read_csv("/course/data/email.csv")
people <- read_csv("/course/data/people.csv")

## Do not modify this line! ## Your code for 2.

email_w_time <- email %>%
  mutate(date = as_datetime(onset)) %>%
  dplyr::select(date, everything())

## Do not modify this line! ## Your code for 3.

email_id_to_name <- function(email_id) {
  email_id %>%
    str_replace_all("\\.", " ") %>%
    str_squish() %>%
    str_to_title()
}

## Do not modify this line! ## Your code for 4.

people_new <- people %>%
  mutate(person_name = ifelse(!is.na(person_name),
    person_name,
    email_id %>% email_id_to_name()
  ))

## Do not modify this line! ## Your code for 5.

role_order <- c(
  "Employee", "Trader", "Manager", "Managing Director",
  "Director", "In House Lawyer", "Vice President", "President", "CEO"
)
people_new2 <- people_new %>%
  replace_na(list(role = "Employee", dept = "General")) %>%
  mutate(role = factor(role, levels = role_order))

## Do not modify this line! ## Your code for 6.

email_w_names <- email_w_time %>%
  left_join(people_new2, by = c("tail" = "vertex.names")) %>%
  rename(
    "receiver_email" = email_id, "receiver" = person_name,
    "receiver_role" = role, "receiver_dept" = dept
  ) %>%
  left_join(people_new2, by = c("head" = "vertex.names")) %>%
  rename(
    "sender_email" = email_id, "sender_name" = person_name,
    "sender_role" = role, "sender_dept" = dept
  ) %>%
  dplyr::filter(sender_email != receiver_email) %>%
  dplyr::select(
    date,
    starts_with("send"),
    starts_with("receiver")
  )

## Do not modify this line! ## Your code for 7.

sender_role_count <- email_w_names %>%
  group_by(sender_role) %>%
  summarize(count = n()) %>%
  arrange(desc(count))

## Do not modify this line! ## Your code for 8.

g1 <- email_w_names %>%
  mutate(hour = hour(date)) %>%
  ggplot(mapping = aes(x = hour)) +
  geom_histogram(bins = 24) +
  labs(
    title = "People send more emails in the middle of the day",
    x = "Hour",
    y = "Count (n)"
  )

## Do not modify this line! ## Your code for 9.

count_by_month <- email_w_names %>%
  filter(year(date) < 2002) %>%
  mutate(date = floor_date(date, unit = "month")) %>%
  group_by(date, sender_role) %>%
  summarize(count = n()) %>%
  arrange(date)

## Do not modify this line! ## Your code for 10.

g2 <- count_by_month %>%
  ggplot(mapping = aes(x = date, y = count, color = sender_role)) +
  geom_point() +
  geom_smooth(method = "loess") +
  labs(
    title = "Emailed activity increased from 1999 to 2001",
    x = "Date",
    y = "Count (n)",
    color = "Sender role"
  )

