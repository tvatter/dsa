### Number of exercises
n_ex <- 10

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw7_email.R", n_ex)
file.remove("solutions/solution_hw7_email.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw7_email.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})



all_names <- dplyr::starwars %>%
  dplyr::pull(name) %>%
  stringr::str_to_lower() %>%
  stringr::str_split("\\s")
first_names <- all_names %>% map_chr(1)
last_names <- all_names %>%
  map_chr(function(x) ifelse(length(x) == 2, x[2], "doe")) %>%
  unique()

sample_email_id <- function(n = 10) {
  first <- sample(first_names, n)
  last <- sample(last_names, n)
  list(email_id = paste(first, ".", last, sep = ""))
}

to_test <- list(
  list(
    test_object("email"),
    test_object("people")
  ),
  test_object("email_w_time"),
  test_object("email_id_to_name", "function",
    input = sample_email_id()
  ),
  test_object("people_new"),
  test_object("people_new2"),
  test_object("email_w_names"),
  test_object("sender_role_count"),
  test_object("g1", "figure"),
  test_object("count_by_month"),
  test_object("g1", "figure")
)


options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(
  list(c("theme_set", "theme_light", "read_csv")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
packages <- c(
  list(c("tidyverse", "lubridate")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
