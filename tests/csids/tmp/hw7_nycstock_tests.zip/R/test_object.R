#' Construct a test object
#'
#' @param name The name of the object to test
#' @param type The type of the object to test
#' @param ... Additional attributes of the test
#' @export
test_object <- function(name, type = c("default", "function",
                                       "figure", "model"),
                        ...) {
  stopifnot(is.vector(name) && is.character(name) && length(name) == 1)
  type <- match.arg(type)
  object <- structure(name, type = type, class = "test_object")
  if (!missing(...)) {
    args <- list(...)
    nn <- names(args)
    if (is.null(nn) || any(nn == "")) {
      stop("Additional attributes need to be named.")
    }

    for (i in nn) {
      attr(object, i) <- args[[i]]
    }
  }
  return(object)
}

#' @importFrom tools .print.via.format
#' @export
print.test_object <- function(x, ...) {
  txt <- paste0("Name: ", x, "\nType: ", attr(x, "type"))
  a <- names(attributes(x))
  if (any(!(a %in% c("type", "class")))) {
    a <- paste(a[!(a %in% c("type", "class"))], collapse = ", ")
    txt <- paste0(txt, "\nAdditional tests: ", a)
  }
  .print.via.format(txt, ...)
  invisible(x)
}
