## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
theme_set(theme_light())

prices <- read_csv("/course/data/prices.csv",
  locale = locale(tz = "America/New_York")
)
securities <- read_csv("/course/data/securities.csv")
fund <- read_csv("/course/data/fundamentals.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

securities_sectored <- securities %>%
  mutate(
    `GICS Sector truncated` = `GICS Sector` %>%
      fct_infreq() %>%
      fct_lump(6)
  ) %>%
  filter(
    `GICS Sector truncated` == "Other",
    !str_detect(`GICS Sub Industry`, "Gold|REITs")
  )

securities_selected <- securities %>%
  anti_join(securities_sectored) %>%
  dplyr::select(`Ticker symbol`, Security, `GICS Sector`)

## Do not modify this line! ## Write your code for 3. after this line! ##

fund_time <- fund %>%
  dplyr::rename(`Ticker symbol` = `Ticker Symbol`) %>%
  mutate(`Period Ending Year` = `Period Ending` %>% mdy() %>% year()) %>%
  drop_na() %>%
  dplyr::select(`Ticker symbol`, `Period Ending Year`, `Gross Margin`)

## Do not modify this line! ## Write your code for 4. after this line! ##

securities_fund <- securities_selected %>%
  inner_join(fund_time, by = "Ticker symbol")

## Do not modify this line! ## Write your code for 5. after this line! ##

gross_margin <- ggplot(
  data = securities_fund,
  mapping = aes(x = `Gross Margin`)
) +
  geom_histogram(binwidth = 10) +
  facet_wrap(~`GICS Sector`) +
  labs(
    title = "The gross margin distribution varies by sector",
    x = "Gross Margin (%)",
    y = "Count (n)"
  )

## Do not modify this line! ## Write your code for 6. after this line! ##

tickers_sectors <- securities_fund %>%
  dplyr::select(`Ticker symbol`, Security, `GICS Sector`) %>%
  unique() %>%
  arrange(`Ticker symbol`)

full_stock <- prices %>%
  dplyr::rename(`Ticker symbol` = `symbol`) %>%
  mutate(year = year(date)) %>%
  dplyr::select(`Ticker symbol`, close, open, date, year) %>%
  left_join(tickers_sectors) %>%
  filter(!is.na(`GICS Sector`))

## Do not modify this line! ## Write your code for 7. after this line! ##

trend <- full_stock %>%
  filter(Security %in%
    c(
      "Aetna Inc", "Amazon.com Inc", "Facebook", "Whole Foods Market",
      "FedEx Corporation", "Boeing Company", "The Walt Disney Company"
    )) %>%
  ggplot(mapping = aes(x = date, y = close, color = Security)) +
  geom_line() +
  labs(
    title = "Amazon's stock price more than doubled!",
    x = "Date",
    y = "Daily close price (USD)"
  )

## Do not modify this line! ## Write your code for 8. after this line! ##

return_stock <- full_stock %>%
  group_by(year, `Ticker symbol`, `GICS Sector`) %>%
  summarize(
    open = open[date == min(date)],
    close = close[date == max(date)],
    return = (close - open) / open
  )

## Do not modify this line! ## Write your code for 9. after this line! ##

summary_stock <- return_stock %>%
  group_by(`GICS Sector`) %>%
  summarize(
    q25 = quantile(return, 0.25),
    mean_return = mean(return),
    q75 = quantile(return, 0.75)
  )

