## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(scales)
theme_set(theme_light())

terms_mentions <- read_tsv("/course/data/mentions_yearly_counts.tsv",
  col_names = c("term", "year", "n_mentions", "book_count"),
  col_types = "ciii"
)

## Do not modify this line! ## Write your code for 2. after this line! ##

total_mentions <- read_csv("/course/data/yearly_total_counts.csv",
  col_names = c(
    "year", "total_mentions",
    "total_page_count", "total_book_count"
  ),
  col_types = "idii"
)

## Do not modify this line! ## Write your code for 3. after this line! ##

mentions <- terms_mentions %>% left_join(total_mentions)

## Do not modify this line! ## Write your code for 4. after this line! ##

diagnosis <- terms_mentions %>% anti_join(mentions)

## Do not modify this line! ## Write your code for 5. after this line! ##

relative_mention_counts <- mentions %>%
  mutate(frac_total = n_mentions / total_mentions) %>%
  dplyr::select(term, year, n_mentions, total_mentions, frac_total)

## Do not modify this line! ## Write your code for 6. after this line! ##

examples_mention_counts <- relative_mention_counts %>%
  filter(term %in% c(1883, 1910, 1950)) %>%
  mutate(term = factor(term) %>% fct_rev())

## Do not modify this line! ## Write your code for 7. after this line! ##

paper_figure <- examples_mention_counts %>%
  ggplot(aes(x = year, y = frac_total, color = term)) +
  geom_line() +
  scale_y_continuous(label = percent) +
  coord_cartesian(xlim = c(1850, 2012)) +
  labs(
    x = "Year",
    y = "Frequency of mention of each term",
    color = "Term",
    title = "Are we neglecting the past faster?"
  )

