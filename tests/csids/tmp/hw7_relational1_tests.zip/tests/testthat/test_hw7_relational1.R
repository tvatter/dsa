### Number of exercises
n_ex <- 7

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw7_relational1.R", n_ex)
file.remove("solutions/solution_hw7_relational1.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw7_relational1.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})

to_test <- list(
  test_object("terms_mentions"),
  test_object("total_mentions"),
  test_object("mentions"),
  test_object("diagnosis"),
  test_object("relative_mention_counts"),
  test_object("examples_mention_counts"),
  test_object("paper_figure", "figure")
)


options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(
  list(c("theme_set", "theme_light", "read_tsv")),
  list("read_csv"),
  replicate(n_ex - 2, NA, simplify = FALSE)
)
packages <- c(
  list(c("tidyverse", "scales")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
