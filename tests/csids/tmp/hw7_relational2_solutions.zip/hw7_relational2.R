## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
library(scales)
theme_set(theme_light())

booking <- read_csv("/course/data/guest_house/booking.csv")
guest <- read_csv("/course/data/guest_house/guest.csv")
rate <- read_csv("/course/data/guest_house/rate.csv")
room <- read_csv("/course/data/guest_house/room.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

room_earning <- booking %>%
  left_join(rate, by = c(
    "room_type_requested" = "room_type",
    "occupants" = "occupancy"
  )) %>%
  mutate(
    earning = amount * nights,
    booking_date = mdy(booking_date),
    room_no = factor(room_no) %>% fct_reorder(earning)
  ) %>%
  arrange(booking_date, room_no) %>%
  dplyr::select(booking_date, room_no, guest_id, nights, earning)

## Do not modify this line! ## Write your code for 3. after this line! ##

room_earning_plot <- room_earning %>%
  ggplot(aes(x = room_no, y = earning)) +
  geom_boxplot() +
  scale_y_continuous(labels = label_dollar()) +
  coord_flip() +
  labs(
    title = "Most rooms have earnings between $100 and $300",
    x = "Room number",
    y = "Earnings"
  )

## Do not modify this line! ## Write your code for 4. after this line! ##

guest_spending <- guest %>%
  mutate(name = paste(first_name, last_name)) %>%
  right_join(room_earning, by = c("id" = "guest_id")) %>%
  group_by(name) %>%
  summarize(
    nights = sum(nights),
    spending = sum(earning)
  ) %>%
  arrange(desc(spending)) %>%
  head(10) %>%
  mutate(name = fct_reorder(name, spending))

## Do not modify this line! ## Write your code for 5. after this line! ##

guest_spending_plot <- guest_spending %>%
  ggplot(aes(x = name, y = spending)) +
  geom_col() +
  scale_y_continuous(labels = label_dollar()) +
  coord_flip() +
  labs(
    title = "Top 10 guests all spent more than $600",
    x = "Name",
    y = "Spending"
  )

