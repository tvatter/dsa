### Number of exercises
n_ex <- 5

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw7_relational2.R", n_ex)
file.remove("solutions/solution_hw7_relational2.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw7_relational2.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})

to_test <- list(
  list(
    test_object("booking"),
    test_object("guest"),
    test_object("rate"),
    test_object("room")
  ),
  test_object("room_earning"),
  test_object("room_earning_plot", "figure"),
  test_object("guest_spending"),
  test_object("guest_spending_plot", "figure")
)


options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(
  list(c("theme_set", "theme_light", "read_csv")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
packages <- c(
  list(c("tidyverse", "lubridate", "scales")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
