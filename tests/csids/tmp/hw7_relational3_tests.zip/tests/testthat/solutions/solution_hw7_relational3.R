## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
theme_set(theme_light())

department <- read_csv("/course/data/department_info.csv")
employee <- read_csv("/course/data/employee_info.csv")
s_admission <- read_csv("/course/data/student_counselling_info.csv")
s_performance <- read_csv("/course/data/student_performance_info.csv")

## Do not modify this line! ## Write your code for 2. after this line! ##

employee_new <- employee %>%
  mutate(
    age = floor(DOB %--% today() / dyears(1)),
    seniority = floor(DOJ %--% today() / dyears(1)),
    seniority_level = cut(seniority,
      breaks = c(min(seniority), 10, max(seniority)),
      labels = c("junior", "senior"),
      include.lowest = TRUE
    )
  ) %>%
  dplyr::select(-DOB, -DOJ)

## Do not modify this line! ## Write your code for 3. after this line! ##

s_admission_new <- s_admission %>%
  mutate(
    age = floor(DOB %--% today() / dyears(1)),
    school_year = DOA %>%
      factor() %>%
      fct_collapse(graduate = c("2013-07-01", "2014-07-01")) %>%
      fct_recode(
        senior = "2015-07-01",
        junior = "2016-07-01",
        sophomore = "2017-07-01",
        freshman = "2018-07-01"
      )
  ) %>%
  dplyr::select(-DOA, -DOB, -Department_Choices)

## Do not modify this line! ## Write your code for 4. after this line! ##

s_performance_new <- s_performance %>%
  group_by(Student_ID) %>%
  summarize(
    mean_score = mean(Marks),
    min_score = min(Marks),
    max_score = max(Marks)
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

department_engie <- department %>%
  filter(str_detect(Department_Name, "(E|e)ngineering")) %>%
  dplyr::select(-DOE)

# Some alternatives for detecting string:
# str_detect(Department_Name, fixed("Engineering", ignore_case = TRUE)
# grepl("Engineering", Department_Name, ignore.case = TRUE) == TRUE
# str_which() is also workable, but needs an extra subsetting step as it
# returns an index.

## Do not modify this line! ## Write your code for 6. after this line! ##

employee_engie <- employee_new %>%
  inner_join(department_engie, by = "Department_ID") %>%
  mutate(Department_Name = Department_Name %>% fct_infreq())

## Do not modify this line! ## Write your code for 7. after this line! ##

g1 <- employee_engie %>%
  ggplot(aes(Department_Name, fill = seniority_level)) +
  geom_bar() +
  coord_flip() +
  labs(
    title = str_wrap("Most departments have more senior professors
                     than juniors", width = 40),
    subtitle = "Exceptions are CASDE and Chemical Engineering",
    x = "Department's name",
    fill = "Seniority level",
    y = "Number of professors"
  )

## Do not modify this line! ## Write your code for 8. after this line! ##

student_engie <- s_admission_new %>%
  inner_join(s_performance_new, by = "Student_ID") %>%
  inner_join(department_engie,
    by = c("Department_Admission" = "Department_ID")
  ) %>%
  mutate(school_year = fct_reorder(school_year, mean_score))

## Do not modify this line! ## Write your code for 9. after this line! ##

g2 <- student_engie %>%
  ggplot(aes(school_year, mean_score)) +
  geom_boxplot() +
  coord_flip() +
  labs(
    title = "Score distribution is similar across years",
    x = "Class standing",
    y = "Mean paper score"
  )

