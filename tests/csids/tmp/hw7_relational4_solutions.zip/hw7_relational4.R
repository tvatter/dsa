## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
theme_set(theme_light())

movies <- read_csv("/course/data/movies.csv")
ratings <- read_csv("/course/data/ratings.csv") %>%
  mutate(date = as_datetime(timestamp))

## Do not modify this line! ## Write your code for 2. after this line! ##

ratings_per_year <- ratings %>%
  mutate(year = year(date)) %>%
  group_by(year) %>%
  summarize(
    mean = mean(rating),
    n = n(),
    sd = sd(rating),
    se = 1.96 * sd / sqrt(n)
  )

## Do not modify this line! ## Write your code for 3. after this line! ##

g1 <- ratings_per_year %>%
  ggplot(aes(x = year, y = mean)) +
  geom_point() +
  geom_errorbar(aes(ymin = mean - se, ymax = mean + se)) +
  labs(
    title = "2004 and 2005 have the lowest average ratings",
    subtitle = "2014 has the highest average ratings",
    x = "Year",
    y = "Average rating (with standard errors)"
  )

## Do not modify this line! ## Write your code for 4. after this line! ##

movies_new <- movies %>%
  mutate(year = str_sub(title, start = -5, end = -2) %>% as.numeric()) %>%
  separate_rows(genres, sep = "\\|")

# an alternative to extract the year using regexps
# year = str_replace(title, ".+\\(([0-9]+)\\)", "\\1")  %>% as.numeric()

## Do not modify this line! ## Write your code for 5. after this line! ##

ratings_of_movies <- inner_join(movies_new, ratings) %>%
  dplyr::select(-c(movieId, userId, timestamp)) %>%
  filter(!(genres == "(no genres listed)"))

## Do not modify this line! ## Write your code for 6. after this line! ##

ratings_by_genres <- ratings_of_movies %>%
  group_by(genres) %>%
  summarize(
    average_rating = mean(rating),
    number_of_ratings = n()
  )

## Do not modify this line! ## Write your code for 7. after this line! ##

g2 <- ratings_by_genres %>%
  ggplot(aes(number_of_ratings, average_rating)) +
  geom_smooth(method = "gam", color = "black") +
  geom_point(aes(color = genres)) +
  scale_x_log10() +
  labs(
    title = str_wrap("When the number of ratings is over 5000,
                     its average plateaus around 3.5"),
    x = "Number of ratings",
    y = "Average rating",
    color = "Genre"
  ) +
  theme(legend.position = "bottom")

## Do not modify this line! ## Write your code for 8. after this line! ##

ratings_over_time <- ratings_of_movies %>%
  mutate(
    interval = date - make_datetime(year),
    years_passed = interval / dyears(1),
    decade = cut(years_passed, seq(0, 120, 20))
  ) %>%
  dplyr::select(genres, interval, years_passed, decade, everything()) %>%
  filter(years_passed <= 80)

## Do not modify this line! ## Write your code for 9. after this line! ##

g3 <- ratings_over_time %>%
  ggplot(aes(genres, rating, color = decade)) +
  geom_linerange(stat = "summary") +
  coord_flip() +
  labs(
    title = "The average rating usually increases with time",
    subtitles = "Exceptions are documentaries and animation movies",
    x = "Genre",
    y = "Average rating (and standard errors)",
    color = "Years between release and rating"
  ) +
  theme(legend.position = "bottom")

