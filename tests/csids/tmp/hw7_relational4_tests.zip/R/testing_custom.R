#' Expectation: does the object has the right dimensions?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param dim Expected dimensions.
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_dim <- function(object, dim, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  act$dim <- dim(act$val)
  expect(
    !is.null(act$dim),
    sprintf("%s has no dim attribute.", act$lab)
  )
  expect(
    length(act$dim) == length(dim) && all(act$dim == dim),
    sprintf("%s has dim %s, not %s.", act$lab, paste0(act$dim, collapse = "x"), paste0(dim, collapse = "x"))
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: does the object has the right length?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param length Expected length.
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_length <- function(object, length, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  act$length <- length(act$val)
  expect(
    length(act$length) == length(length) && all(act$length == length),
    sprintf("%s has length %s, not %s.", act$lab, act$length, length)
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: was the given function used?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param chunk Chunk to test. If a function is passed, then it's body is analyzed.
#' @param name Name of the function to look for.
#' @param used Should we expect the function to be used or not?
#' @param exceptions In case the function should not be used, but there might be exceptions.
#' @param label Used to customise failure messages.
#' @importFrom stringr str_detect str_remove_all fixed
#' @importFrom purrr reduce
#' @export
expect_function <- function(chunk, name, used = TRUE, exceptions = NULL,
                            label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(chunk), label, arg = "chunk")
  fct <- is.function(act$val)
  if (fct) {
    to_parse <- paste0(deparse(body(act$val)), collapse = " ")
  } else {
    to_parse <- act$val
  }

  # 2. Call expect()
  if (!is.null(exceptions)) {
    to_parse <- reduce(fixed(exceptions), str_remove_all, .init = to_parse)
  }
  act$detect <- str_detect(to_parse, fixed(name))
  if (used) {
    expect(
      act$detect,
      ifelse(fct,
        sprintf("The function %s was not used in %s.", name, act$lab),
        sprintf("The function %s was not used.", name)
      )
    )
  } else {
    expect(
      act$detect == used,
      ifelse(fct,
        sprintf(
          "The function %s was used in the body of function %s but shouldn't have been.",
          name, act$lab
        ),
        sprintf("The function %s was used but shouldn't have been.", name)
      )
    )
  }

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: have the two functions the same arguments?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param func1 First function.
#' @param func2 Second function.
#' @param label Used to customise failure messages.
#' @export
expect_arguments <- function(func1, func2, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(func1), label, arg = "func1")
  formals1 <- names(formals(func1))
  formals2 <- names(formals(func2))

  # 2. Call expect()
  expect(
    length(formals1) == length(formals2),
    sprintf(
      "%s has %s arugments instead of %s.", act$lab,
      length(formals1), length(formals2)
    )
  )
  expect(
    all(formals1 == formals2),
    glue("{act$lab} has arguments {formals1} instead of {formals2}.",
      .transformer = my_collapse_transformer
    )
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: does an object with that name exists in a given environment?
#'
#' Here, using the three steps is definitely overkill, but I just copy-pasted.
#'
#' @param env Environment to test.
#' @param name Expected name.
#' @export
expect_exists <- function(env, name) {

  # 1. Capture object and label
  act <- quasi_label(enquo(env), arg = "env")

  # 2. Call expect()
  act$val <- exists(name, where = env)
  expect(
    act$val,
    sprintf("The variable `%s` is missing.", name)
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: is the package attached to the environment?
#'
#' @param env Environment to test.
#' @param expected Expected package.
#' @param isloaded To check whether the package is missing
#' or shouldn't be loaded.
#' @importFrom stringr str_remove
#' @importFrom rlang eval_tidy
#' @export
expect_package <- function(env, expected, isloaded = TRUE) {
  act <- quasi_label(enquo(env), arg = "env")
  # Capture the loaded environments
  act$val <- str_remove(eval(search, env)(), "package:")
  if (isloaded) {
    expect(
      expected %in% act$val,
      sprintf("The package with name %s is missing.", expected)
    )
  }
  else {
    expect(
      !(expected %in% act$val),
      sprintf("The package with name %s should not be loaded.", expected)
    )
  }
  invisible(act$val)
}

#' Expectation: does the object has the right class?
#'
#' @param object Object to test.
#' @param expected Expected class.
#' @param label Used to customise failure messages.
#' @importFrom tibble is_tibble
#' @export
expect_class <- function(object, expected, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  if (exists(paste0("is.", expected)) && expected != "tibble") {
    is_expected <- get0(paste0("is.", expected))
  } else {
    is_expected <- switch(expected,
      tibble = tibble::is_tibble,
      tbl_df = tibble::is_tibble,
      function(x) inherits(x, expected)
    )
  }

  # 2. Call expect()
  expect(
    is_expected(act$val),
    glue("{act$lab} has class {class(act$val)} instead of {expected}.",
      .transformer = my_collapse_transformer
    )
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: does the object has the right S3 status?
#'
#' @param object Object to test.
#' @param expected Object to compare to.
#' @param fname Name of the function to test.
#' @export
expect_ftype <- function(object, expected, fname) {

  # 1. Check object's ftype
  object_ftype <- ftype_in_env(object, environment(object), fname)
  expected_ftype <- ftype_in_env(expected, environment(expected), fname)

  # 2. Call expect_equivalent_default()
  expect_equivalent_default(object_ftype,
    expected_ftype,
    label = glue("sloop::ftype({fname})")
  )

  # 3. Invisibly return the value
  invisible(object)
}

#' Expectation: does the object has the right names?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param expected Expected names
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_names <- function(object, expected, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  expect(
    identical(names(act$val), expected),
    glue("{act$lab} has names {names(act$val)} instead of {expected}.",
      .transformer = my_collapse_transformer
    )
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: does the object has the right column/row names?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param expected Expected names
#' @param label Used to customise failure messages.
#' @param type Either `"column"` or `"row`.
#' @export
expect_dimnames <- function(object, expected, label = NULL, type = "column") {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  if (type == "column") {
    act$names <- colnames(act$val)
  } else {
    act$names <- rownames(act$val)
  }

  ok <- identical(act$names, expected)
  if (!ok && length(act$names) == 0) {
    act$names <- "empty"
  }
  if (!ok && is.null(expected)) {
    expected <- "empty"
  }
  expect(
    ok,
    glue("{act$lab} has {type} names {act$names} instead of {expected}.",
      .transformer = my_collapse_transformer
    )
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: Is the vector in interval `[a,b]`?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test (already passed expect_vector and length > 1).
#' @param a Lower bound of the interval.
#' @param b Upper bound of the interval.
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_interval <- function(object, a, b, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  act$min <- min(act$val)
  act$max <- max(act$val)
  expect(
    a <= act$min && act$max <= b,
    sprintf("%s values are not in the interval [%s, %s].", act$lab, a, b)
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: Is the vector in increasing or decreasing order?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test
#' @param str "decreasing" or "increasing"
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_sorted <- function(object, str, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  if (str == "increasing") {
    expect(
      !is.unsorted(act$val, na.rm = TRUE),
      sprintf("`%s` is not sorted in increasing order.", act$lab)
    )
  }
  else {
    expect(
      !is.unsorted(-act$val, na.rm = TRUE),
      sprintf("`%s` is not sorted in decreasing order.", act$lab)
    )
  }

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: Are all the vector elements higher than M?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param M Lower bound of the vector
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_higher <- function(object, M, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  act$min <- min(act$val)
  expect(
    M <= act$min,
    sprintf("%s values are not higher than %s.", act$lab, M)
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: Are all the vector elements lower than M?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param M Higher bound of the vector
#' @param label Used to customise failure messages.
#' @importFrom testthat expect quasi_label
#' @importFrom rlang enquo
#' @export
expect_lower <- function(object, M, label = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")

  # 2. Call expect()
  act$max <- max(act$val)
  expect(
    act$max <= M,
    sprintf("%s values are not lower than %s.", act$lab, M)
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: is the figure produce the doppelganger of the one in the solution?
#'
#' @param submission The submission environment.
#' @param solution The solution environment.
#' @param figure_name The name of the figure to test.
#' @param dpi The resolution for the comparison, see `ggplot2::ggsave()`.
#' @param threshold A threshold to make the comparison less sensitive
#' (when it is increased), see `visualTest::isSimilar()`.
#' @importFrom visualTest getFingerprint isSimilar
#' @importFrom glue glue
#' @importFrom ggplot2 ggsave
#' @export
expect_figure <- function(submission, solution, figure_name, dpi = 50, threshold = 0.001) {
  figure_submission <- tempfile(fileext = ".png")
  ggsave(figure_submission,
    plot = get(figure_name, envir = submission),
    dpi = dpi
  )

  figure_solution <- tempfile(fileext = ".png")
  ggsave(figure_solution,
    plot = get(figure_name, envir = solution),
    dpi = dpi
  )

  figure_solution <- getFingerprint(figure_solution)

  expect(
    isSimilar(figure_submission, figure_solution, threshold = threshold),
    glue("Your {figure_name} is not similar enough to the solution.")
  )
}

#' Expectation: is the model correct?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param expected Target model
#' @param label Used to customise failure messages.
#' @param label_exp Used to customise failure messages.
#' @importFrom stats coef
#' @importFrom testthat compare
#' @export
expect_equivalent_model <- function(object, expected,
                                    label = NULL, label_exp = NULL) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")
  exp <- quasi_label(enquo(expected), label_exp, arg = "expected")
  act$val <- force(act$val)
  exp$val <- force(exp$val)

  # Test the class
  expect_class(act$val, class(exp$val)[1], label = act$lab)

  # Test same coef names
  msg <- glue("{act$lab} has coefficients {names(coef(act$val))} instead of {names(coef(exp$val))}.",
    .transformer = my_collapse_transformer
  )
  comp <- compare(names(coef(act$val)), names(coef(exp$val)),
    check.attributes = FALSE
  )
  expect(comp$equal, msg)

  # Test same number of observations
  msg <- glue("{act$lab} has been fitted on {length(act$val$residuals)} observations instead of {length(exp$val$residuals)}.",
    .transformer = my_collapse_transformer
  )
  comp <- compare(length(act$val$residuals), length(exp$val$residuals), check.attributes = FALSE)
  expect(comp$equal, msg)

  # Test equivalence
  no_compare <- which(!(names(act$val) %in% c("call", "formula")))
  expect_equivalent_default(act$val[no_compare],
                           exp$val[no_compare],
                           act$lab,
                           exp$lab)

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: is the tibble correct?
#'
#' See https://testthat.r-lib.org/articles/custom-expectation.html.
#'
#' @param object Object to test.
#' @param expected Target model
#' @param label Used to customise failure messages.
#' @param ... passed on compare(), used to control the details of the comparison.
#' @export
expect_tibble <- function(object, expected, label = NULL, ...) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")
  exp <- quasi_label(enquo(expected), arg = "expected")

  # 2. all the tests
  expect_class(act$val, "tibble", label = act$lab)
  expect_dim(act$val, dim(exp$val), label = act$lab)
  expect_names(act$val, names(exp$val), label = act$lab)
  expect_equivalent(as.data.frame(exp$val),
    as.data.frame(act$val),
    label = act$lab,
    expected.label = exp$lab,
    ...
  )

  # 3. Invisibly return the value
  invisible(act$val)
}

#' Expectation: is the figure a doppelganger of the other?
#'
#' @param object Object to test.
#' @param expected Target objet.
#' @param label Used to customise failure messages.
#' @param label_exp Used to customise failure messages.
#' @param dpi The resolution for the comparison, see `ggplot2::ggsave()`.
#' @param threshold A threshold to make the comparison less sensitive
#' (when it is increased), see `visualTest::isSimilar()`.
#' @param ... passed on `visualTest::isSimilar()`, used to control the
#' details of the comparison.
#' @importFrom visualTest getFingerprint isSimilar
#' @importFrom ggplot2 ggsave
#' @export
expect_equivalent_figure <- function(object, expected,
                                     label = NULL, label_exp = NULL,
                                     dpi = 50, threshold = 0.001, ...) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")
  exp <- quasi_label(enquo(expected), label_exp, arg = "expected")

  # Test the class
  expect_class(act$val, "ggplot", label = act$lab)

  # 2. Save the figures as png
  figure_submission <- tempfile(fileext = ".png")
  ggsave(figure_submission,
    plot = act$val,
    dpi = dpi
  )

  figure_solution <- tempfile(fileext = ".png")
  ggsave(figure_solution,
    plot = exp$val,
    dpi = dpi
  )

  figure_solution <- getFingerprint(figure_solution)

  # 3. Add potential additional arguments
  pars <- list(
    file = figure_submission,
    fingerprint = figure_solution,
    threshold = threshold
  )
  pars <- modifyList(pars, list(...))

  # 4. Test for similarity
  expect(
    do.call(isSimilar, pars),
    glue("Your {act$lab} figure is not similar enough to the solution.")
  )

  # 5. Return the object invisibly
  invisible(act$val)
}

#' Expectation: is the object equal to a value?
#'
#' Same as `expect_equivalent`, but with improved messages in case the
#' type or class are not equivalent (and also for the dimension).
#'
#' @param object Object to test.
#' @param expected Target objet.
#' @param label Used to customise failure messages.
#' @param label_exp Used to customise failure messages.
#' @param ... passed on `compare()`, used to control the details of the
#'        comparison.
#' @importFrom rlang is_vector is_atomic
#' @importFrom tibble as_tibble
#' @importFrom sloop otype
#' @importFrom testthat expect_equivalent
#' @export
expect_equivalent_default <- function(object, expected,
                                     label = NULL, label_exp = NULL, ...) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")
  exp <- quasi_label(enquo(expected), label_exp, arg = "expected")

  # 2. Tests

  # Test class and type
  expect_class(act$val, class(exp$val)[1], label = act$lab)
  expect(
    typeof(act$val) == typeof(exp$val),
    glue("{act$lab} has type '{typeof(act$val)}` instead of `{typeof(exp$val)}`.")
  )

  # Test dimension or length
  if (!is.null(dim(exp$val))) {
    expect_dim(act$val, dim = dim(exp$val), label = act$lab)
  } else {
    expect_length(act$val, length = length(exp$val), label = act$lab)
  }

  # # Improved error messages for sorted numeric vectors
  # if (!(otype(exp$val) == "S3") && is_vector(exp$val) && is.numeric(exp$val)) {
  #   if (!is.unsorted(exp$val, na.rm = TRUE)) {
  #     expect_sorted(act$val, "increasing", act$lab)
  #   }
  #   if (!is.unsorted(-exp$val, na.rm = TRUE)) {
  #     expect_sorted(act$val, "decreasing", act$lab)
  #   }
  # }

  # For matrices, check row and column names
  if (inherits(exp$val, "matrix")) {
    expect_dimnames(act$val, colnames(exp$val), label = act$lab)
    expect_dimnames(act$val, rownames(exp$val), label = act$lab, type = "row")
  }

  # Transform tibbles to data frames as they can be tested for near equivalency
  tbl_df <- FALSE
  if (inherits(exp$val, "tbl_df")) {
    tbl_df <- TRUE
    act$val <- as.data.frame(act$val)
    exp$val <- as.data.frame(exp$val)
  }

  # Tibbles, data frames and should always have names
  if (inherits(exp$val, c("data.frame", "list"))) {
    expect_names(act$val, names(exp$val), label = act$lab)
  }

  # Add potentiall additional arguments
  pars <- list(
    object = act$val,
    expected = exp$val,
    label = act$lab,
    expected.label = exp$lab,
    max_diffs = 3
  )
  pars <- modifyList(pars, list(...))

  # Test equivalency
  do.call(expect_equivalent, pars)

  # 3. Invisibly return the value
  if (tbl_df) {
    act$val <- as_tibble(act$val)
  }
  invisible(act$val)
}

#' @importFrom glue glue_collapse
collapse_transformer <- function(regex = "[*]$", ...) {
  function(text, envir) {
    if (grepl(regex, text)) {
      text <- sub(regex, "", text)
    }
    res <- eval(parse(text = text, keep.source = FALSE), envir)
    args <- modifyList(list(x = res), list(...))
    do.call(glue_collapse, args)
  }
}
my_collapse_transformer <- collapse_transformer(sep = ", ", last = " and ")

#' Expectation: is the function equivalent to another?
#'
#' Test arguments and inputs/outputs of functions based on randomized tests.
#'
#' @param object Object to test.
#' @param expected Target objet.
#' @param label Used to customise failure messages.
#' @param label_exp Used to customise failure messages.
#' @param ... Randomized test specific to the function
#' @importFrom purrr imap map_lgl
#' @importFrom rlang is_double is_character inherits_any
#' @importFrom testthat capture_output_lines
#' @importFrom assertthat assert_that
#' @export
expect_equivalent_function <- function(object, expected,
                                       label = NULL, label_exp = NULL,
                                       ...) {

  # 1. Capture object and label
  act <- quasi_label(enquo(object), label, arg = "object")
  exp <- quasi_label(enquo(expected), label_exp, arg = "expected")

  # 2. Tests

  # Test class and type
  expect_class(act$val, "function", label = act$lab)
  expect_arguments(act$val, exp$val, label = act$lab)
  if (!inherits_any(expected, c(
    "purrr_function_compose",
    "purrr_function_partial"
  ))) {
    expect_ftype(object, expected, label)
    ftype_expected <- ftype_in_env(expected, environment(expected), label)
  } else {
    ftype_expected <- "function"
  }


  # Custom tests
  custom_tests <- list(...)

  # Test a function's content
  if ("content" %in% names(custom_tests)) {
    id <- which("content" == names(custom_tests))
    content <- custom_tests[[id]]
    for (i in seq_along(content$fct)) {
      expect_function(act$val, content$fct[i], content$used[i], label = act$lab)
    }
    custom_tests <- custom_tests[-id]
  }

  # Deal with s3 methods
  if (length(ftype_expected) == 1 && ftype_expected == "function") {
    s3_type <- NULL
  } else if (identical(ftype_expected, c("S3", "method"))) {
    s3_type <- strsplit(label, "\\.")[[1]][2]
    label <- strsplit(label, "\\.")[[1]][1]
    if (s3_type == "default") {
      s3_type <- NULL
    } else {
      act$s3_ctor <- get(s3_type, envir = environment(act$val))
      exp$s3_ctor <- get(s3_type, envir = environment(exp$val))
    }
  } else {
    if ("input" %in% names(custom_tests)) {
      stop(glue("input not supported for sloop::ftype equal to {ftype_expected}",
        .transformer = my_collapse_transformer
      ))
    }
  }

  # Randomized with input/output
  if ("input" %in% names(custom_tests)) {

    # extract inputs to test
    id <- which("input" == names(custom_tests))
    input <- custom_tests[[id]]
    custom_tests <- custom_tests[-id]

    # extract inputs (e.g., for function factories)
    if ("input_secondary" %in% names(custom_tests)) {
      id <- which("input_secondary" == names(custom_tests))
      input_secondary <- custom_tests[[id]]
      custom_tests <- custom_tests[-id]
      if (length(input[[1]]) != length(input_secondary[[1]])) {
        browser()
      }
    }

    # extract output type (e.g., models)
    if ("output_type" %in% names(custom_tests)) {
      id <- which("output_type" == names(custom_tests))
      output_type <- custom_tests[[id]]
      custom_tests <- custom_tests[-id]
    } else {
      output_type <- "default"
    }

    # sanity check
    args <- names(input)
    normal_function <- is.null(s3_type) &&
      (compare(names(formals(exp$val)), args)$equal ||
        (all(setdiff(names(formals(exp$val)), "...") %in% args) &&
          "..." %in% names(formals(exp$val))))
    s3_method <- !is.null(s3_type) &&
      compare(names(formals(exp$s3_ctor)), args)$equal
    # s3_triple_dot <- !is.null(s3_type) &&
    #   compare(names(formals(exp$val)), "...")$equal
    check_formals <- normal_function || s3_method
    if (!check_formals) {
      browser()
    }
    # assert_that()

    # Building the generic messages
    input_msg <- input_txt_all(input)
    if (!is.null(s3_type)) {
      input_msg <- paste(s3_type, "(", input_msg, ")", sep = "")
    }
    msg <- get_msg_all(input_msg)

    # Building function calls
    calls <- get_call_all(input, is_s3 = !is.null(s3_type))

    # Same with the seconday input if needed
    if (exists("input_secondary")) {
      input_msg_secondary <- input_txt_all(input_secondary,
        postfix = "secondary"
      )
      msg_secondary <- get_msg_all(input_msg, input_msg_secondary)
      calls_secondary <- get_call_all(input, input_secondary)
    }

    for (j in seq_along(input[[1]])) {

      # Fix the function calls for NULL inputs
      calls_fixed <- fix_null_calls(calls, input, j)

      # Function calls (capturing outputs as well as exceptions)
      act_eval <- capture_all(calls_fixed$call_act)
      exp_eval <- capture_all(calls_fixed$call_exp)

      # Same for the secondary inputs if needed
      if (exists("input_secondary")) {
        calls_fixed <- fix_null_calls(calls_secondary, input, j)
        calls_fixed <- fix_null_calls(calls_fixed, input_secondary, j, TRUE)
        act_eval_secondary <- capture_all(calls_fixed$call_act)
        exp_eval_secondary <- capture_all(calls_fixed$call_exp)
      }

      # Format input for printing
      input <- format_input(input, j)
      if (exists("input_secondary")) {
        input_secondary <- format_input(input_secondary, j)
      }

      # Check if thrown exception coincide
      problem <- expect_exception(
        act_eval$res, exp_eval$res,
        label, j, msg, input
      )
      if (problem) {
        break
      }
      if (exists("input_secondary")) {
        problem <- expect_exception(
          act_eval_secondary$res,
          exp_eval_secondary$res,
          label, j, msg_secondary,
          input, input_secondary
        )
        if (problem) {
          break
        }
      }

      # Check if the print/cat/message outputs coincide
      expect_equivalent_default(
        object = act_eval$out,
        expected = exp_eval$out,
        label = glue(msg$act_out_msg),
        label_exp = glue(msg$exp_out_msg)
      )

      # if (label == "boot_parametric_factory")
      #   browser()
      # Check the actual output
      if (!exists("input_secondary")) {
        # Check the actual output
        pars <- list(
          object = act_eval$res,
          expected = exp_eval$res,
          label = glue(msg$act_msg),
          label_exp = glue(msg$exp_msg)
        )
        pars <- modifyList(pars, custom_tests)
        expect_equivalent_switch(pars, output_type)
      } else {
        # Check that the arguments coincide
        expect_arguments(act_eval$res, exp_eval$res, label = glue(msg$act_msg))

        # Check if the print/cat/message outputs coincide
        expect_equivalent_default(
          object = act_eval_secondary$out,
          expected = act_eval_secondary$out,
          label = glue(msg_secondary$act_out_msg),
          label_exp = glue(msg_secondary$exp_out_msg)
        )

        # Check the actual output
        pars <- list(
          object = act_eval_secondary$res,
          expected = exp_eval_secondary$res,
          label = glue(msg_secondary$act_msg),
          label_exp = glue(msg_secondary$exp_msg)
        )
        pars <- modifyList(pars, custom_tests)
        expect_equivalent_switch(pars, output_type)
      }
    }
  }

  invisible(act$val)
}

#' Expectation: does the object exists and is it equivalent to the solution?
#'
#' @param submission The submission environment.
#' @param solution The solution environment.
#' @param object An object of class `test_object` with the relevant information
#' for the test.
#' @importFrom utils modifyList
#' @export
expect_object <- function(submission, solution, object) {
  stopifnot(inherits(submission, "environment"))
  stopifnot(inherits(solution, "environment"))
  stopifnot(inherits(object, "test_object"))

  # check if the object exists in the submission
  object_name <- as.character(object)
  expect_exists(submission, object_name)

  # test whether the object is as expected
  if (exists(object_name, where = submission)) {
    type <- attr(object, "type")
    pars <- list(
      object = get(object_name, envir = submission),
      expected = get(object_name, envir = solution),
      label = object_name,
      label_exp = paste0(object_name, "_solution")
    )

    additional_tests <- !(names(attributes(object)) %in% c("class", "type"))
    if (any(additional_tests)) {
      pars <- modifyList(pars, attributes(object)[additional_tests])
    }

    expect_equivalent_switch(pars, type)
  }
}

expect_equivalent_switch <- function(pars, type) {
  switch(type,
         "default" = do.call(expect_equivalent_default, pars),
         "function" = do.call(expect_equivalent_function, pars),
         "figure" = do.call(expect_equivalent_figure, pars),
         "model" = do.call(expect_equivalent_model, pars)
  )
}
