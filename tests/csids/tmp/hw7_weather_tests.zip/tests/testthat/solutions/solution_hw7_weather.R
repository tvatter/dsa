## Do not modify this line! ## Write your code for 1. after this line! ##

library(tidyverse)
library(lubridate)
library(rattle)
theme_set(theme_light())

data(weather)
weather <- as_tibble(weather)

## Do not modify this line! ## Write your code for 2. after this line! ##

weather_9am <- weather %>%
  dplyr::select(Date, ends_with("9am")) %>%
  rename_all(~ str_remove(., "9am")) %>%
  mutate(Date = ymd_hms(paste(Date, "09:00:00"), tz = "Australia/Canberra"))

weather_3pm <- weather %>%
  dplyr::select(Date, ends_with("3pm")) %>%
  rename_all(~ str_remove(., "3pm")) %>%
  mutate(Date = ymd_hms(paste(Date, "15:00:00"), tz = "Australia/Canberra"))

## Do not modify this line! ## Write your code for 3. after this line! ##

humidity_temp <- full_join(weather_9am, weather_3pm) %>%
  mutate(
    hour = factor(hour(Date)),
    yday = yday(Date)
  ) %>%
  dplyr::select(yday, hour, Humidity, Temp) %>%
  pivot_longer(cols = c("Humidity", "Temp")) %>%
  arrange(yday, hour)

## Do not modify this line! ## Write your code for 4. after this line! ##

temp_humidity_plot <- humidity_temp %>%
  ggplot(aes(x = yday, y = value, col = hour, linetype = name)) +
  geom_smooth(method = "loess", se = FALSE) +
  labs(
    title = "Temperature and humidity are negatively correlated",
    x = "Day of the year",
    y = "Humidity (percent) and temperature (degrees C)",
    color = "Hour",
    linetype = "Measurement"
  )

## Do not modify this line! ## Write your code for 5. after this line! ##

weather_wind_9am <- weather_9am %>%
  dplyr::select(WindDir, Temp) %>%
  mutate(Hour = "9am")

weather_wind_3pm <- weather_3pm %>%
  dplyr::select(WindDir, Temp) %>%
  mutate(Hour = "3pm")

weather_wind <- full_join(weather_wind_9am, weather_wind_3pm) %>%
  drop_na() %>%
  mutate(
    WindMainDir = str_sub(WindDir, 1, 1) %>% factor(),
    Hour = factor(Hour, levels = c("9am", "3pm"))
  )

## Do not modify this line! ## Write your code for 6. after this line! ##

wind_boxplot <- weather_wind %>%
  ggplot(aes(WindMainDir, Temp)) +
  geom_boxplot() +
  facet_grid(~Hour) +
  labs(
    title = "Temperature is higher in the afternoon",
    subtitle = str_wrap("In the morning, it decreases when
                         the winds turns from East to West", width = 70),
    x = "Wind direction",
    y = "Temperature (degree C)"
  )

