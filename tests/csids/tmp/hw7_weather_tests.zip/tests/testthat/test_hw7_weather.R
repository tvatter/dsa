### Number of exercises
n_ex <- 6

## Create a solution environment
solution <- new.env()
solution_chunks <- extract_chunks("solutions/solution_hw7_weather.R", n_ex)
file.remove("solutions/solution_hw7_weather.R")

## Create a submission environment
submission <- new.env()
submission_chunks <- extract_chunks("/home/hw7_weather.R", n_ex)

## Cheating
test_that("No cheating", {
  forgiven_words <- c("assign", "env", "exist", "file", "get", "object", "solution")
  for (i in 1:n_ex) {
    for (j in seq_along(forgiven_words)) {
      expect_function(submission_chunks[i], forgiven_words[j], FALSE, "else")
    }
  }
})

to_test <- list(
  test_object("weather"),
  list(
    test_object("weather_9am"),
    test_object("weather_3pm")
  ),
  test_object("humidity_temp"),
  test_object("temp_humidity_plot", "figure"),
  list(
    test_object("weather_wind_9am"),
    test_object("weather_wind_3pm"),
    test_object("weather_wind")
  ),
  test_object("wind_boxplot", "figure")
)


options(tibble.width = 70)
seeds <- NULL
loops <- c("for", "while", "repeat")
forbidden <- replicate(n_ex, loops, simplify = FALSE)
functions <- c(
  list(c("theme_set", "theme_light")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
packages <- c(
  list(c("tidyverse", "lubridate", "rattle")),
  replicate(n_ex - 1, NA, simplify = FALSE)
)
test_exercise(
  submission_chunks, solution_chunks,
  submission, solution,
  to_test, seeds,
  functions,
  forbidden,
  packages
)
